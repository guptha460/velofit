package com.sap.demo.velofit.global;

import javax.ws.rs.ApplicationPath;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.glassfish.jersey.linking.DeclarativeLinkingFeature;
import org.glassfish.jersey.media.multipart.MultiPartFeature;
import org.glassfish.jersey.server.ResourceConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.sap.demo.velofit.global.CharsetResponseFilter;

/**
 * The Jersey Application is the most important part for providing Jersey web
 * service endpoints, because it registers all the endpoint implementations and
 * it defines the root path /api as defined in the web.xml.
 */
@ApplicationPath("api")
// Note: The path /api is also defined in the web.xml
public class JerseyApplication extends ResourceConfig {

	final static Logger logger = LoggerFactory.getLogger(JerseyApplication.class);

	/**
	 * Constructor to register all service implementing POJOs as Jersey
	 * services, register the PU and so on.
	 * 
	 * @param persistenceUnitName
	 */
	public JerseyApplication() {
		// Register REST/Jersey Services/POJOs
		register(com.sap.demo.velofit.api.Api.class);
		register(com.sap.demo.velofit.api.User.class);

		// Java Architecture for XML Binding (JAXB) allows us to map Java
		// classes to XML representations.
		register(JacksonFeature.class);

		// Register data upload feature
		register(MultiPartFeature.class);

		// Register the charset response filter
		register(new CharsetResponseFilter());

		// Enable URI injection into entities
		register(DeclarativeLinkingFeature.class);
	}

}