package com.sap.demo.velofit.api;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sap.demo.velofit.utils.OAuthUtil;

@Path("/")
public class User {

	private final static Logger logger = LoggerFactory.getLogger(User.class);

	/**
	 * Please note there are two additional user attributes you can use to
	 * retrieve token specific information:
	 * <ul>
	 * <li>com.sap.security.oauth2.clientId - holds information about the OAuth
	 * client ID</li>
	 * <li>com.sap.security.oauth2.grantedScopes - holds information about the
	 * granted scopes</li>
	 * </ul>
	 *
	 * @param request
	 * @return
	 */
	@GET
	@Path("oauth/user")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getUser(@Context HttpServletRequest request) {
		try {
			if (request.getParameter("access_token") != null && !request.getParameter("access_token").isEmpty()) {
				String accessToken = request.getParameter("access_token");
				logger.debug("access_token={}", accessToken);

				ObjectMapper mapper = new ObjectMapper();
				JsonNode user = OAuthUtil.getUserPrincipal(accessToken);
				if (user != null) {

					ObjectNode result = mapper.createObjectNode();
					result.set("user", user);
					return Response.status(Status.OK).entity(result).build();
				} else {
					logger.debug("user==null");
					return Response.status(Status.NOT_FOUND).build();
				}
			} else {
				return Response.status(Status.OK).entity("").build();
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e);
			return Response.status(Status.INTERNAL_SERVER_ERROR)
					.entity("LocalizedMessage: " + e.getLocalizedMessage() + ", Message: " + e.getMessage()).build();
		}
	}
}
