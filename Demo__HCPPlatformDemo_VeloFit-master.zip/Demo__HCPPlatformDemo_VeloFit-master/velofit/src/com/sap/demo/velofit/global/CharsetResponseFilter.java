package com.sap.demo.velofit.global;

import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerResponseContext;
import javax.ws.rs.container.ContainerResponseFilter;
import javax.ws.rs.core.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The Charset Response Filter is used by Jersey to set the default charset to
 * UTF-8 for all responses from the jersey web service endpoints. But only in
 * case that there is NO charset defined.
 */
public class CharsetResponseFilter implements ContainerResponseFilter {

	final static Logger logger = LoggerFactory.getLogger(CharsetResponseFilter.class);

	@Override
	public void filter(ContainerRequestContext httpServletRequest, ContainerResponseContext httpServletResponse) {
		MediaType type = httpServletResponse.getMediaType();
		if (type != null) {
			String ContentType = type.toString();
			if (!ContentType.contains("charset")) {
				ContentType = ContentType + ";charset=utf-8";
				httpServletResponse.getHeaders().putSingle("Content-Type", ContentType);
			}
		}
	}

}