package com.sap.demo.velofit.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLEncoder;
import javax.naming.Context;
import javax.naming.InitialContext;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.DestinationFactory;
import com.sap.core.connectivity.api.http.HttpDestination;

public class OAuthUtil {

	private static final Logger logger = LoggerFactory.getLogger(OAuthUtil.class);

	public static JsonNode getUserPrincipal(String accessToken) {
		JsonNode userPrincipal = null;
		BufferedReader bufferedReader = null;
		try {
			Context context = new InitialContext();

			DestinationFactory destinationFactory = (DestinationFactory) context.lookup(DestinationFactory.JNDI_NAME);
			/*
			 * The "oauth" destination is available within HCP Java EE 6 runtime
			 * by default. Please create no other destination with this name.
			 */
			HttpDestination destination = (HttpDestination) destinationFactory.getDestination("oauth");
			HttpClient httpClient = destination.createHttpClient();
			HttpParams httpParams = httpClient.getParams();
			int timeout = 5;
			HttpConnectionParams.setConnectionTimeout(httpParams, timeout * 1000);
			HttpConnectionParams.setSoTimeout(httpParams, timeout * 1000);

			HttpGet httpRequest = new HttpGet();
			if (accessToken != null) {
				httpRequest.setHeader("access_token", accessToken);
				httpRequest.setHeader("Accept", "application/json");
				httpRequest.setURI(new URI(
						destination.getURI().toString() + "?tenant_id=" + URLEncoder.encode(getTenantId(), "UTF-8")));

				HttpResponse httpResponse = httpClient.execute(httpRequest);
				int httpStatusCode = httpResponse.getStatusLine().getStatusCode();
				StringBuffer stringResponse = new StringBuffer();
				if (200 <= httpStatusCode && httpStatusCode <= 299) {
					bufferedReader = new BufferedReader(new InputStreamReader(httpResponse.getEntity().getContent()));
					String inputLine;
					while ((inputLine = bufferedReader.readLine()) != null) {
						stringResponse.append(inputLine);
					}
					bufferedReader.close();
					logger.debug("stringResponse.toString()={}", stringResponse.toString());

					ObjectMapper mapper = new ObjectMapper();
					userPrincipal = mapper.readTree(stringResponse.toString());
				}
			} else {
				throw new Exception("Access Token cannot be null.");
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e);
		}
		return userPrincipal;
	}

	/**
	 *
	 * @return String Tenant ID
	 */
	private static String getTenantId() {
		String tenantId = null;
		try {
			Context context = new InitialContext();
			TenantContext tenantContext = (TenantContext) context.lookup("java:comp/env/TenantContext");
			if (tenantContext != null) {
				tenantId = tenantContext.getTenant().getId();
			}
		} catch (Exception e) {
			logger.error("Exception: {}", e);
		}
		return tenantId;
	}

}
