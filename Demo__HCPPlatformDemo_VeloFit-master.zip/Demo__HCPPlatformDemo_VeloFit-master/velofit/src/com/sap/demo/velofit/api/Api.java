package com.sap.demo.velofit.api;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

@Path("/")
public class Api {

	/**
	 * 
	 * @return Returns the available resources and further information to these
	 *         resources.
	 */
	@GET
	@Path("api")
	@Produces({ MediaType.APPLICATION_JSON })
	public Response getApi() {
		return Response.status(Status.NOT_IMPLEMENTED).build();
	}

}