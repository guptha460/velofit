# Demo__HCPPlatformDemo_VeloFit
SAP HCP Java Application used for FitSAP<->Velotics integration.

## Overview
### SAP HCP Runtime
- Java EE 6 Web Profile
- Java 1.7

### Currently Deployed Applications
- Application name *velofit* in SAP HCP Account *SDCPlatformVeloticsDev (a51ce4e92)*
- Application name *velofit* in SAP HCP Account *SDCPlatformVelotics (a6402f209)*

## Documentation
### API Endpoints
The API root is */api* and there is currently no authentication necessary.

#### OAuth Endpoint
The OAuth Endpoint */api/oauth* is responsible for everything related to OAuth.

##### OAuth User Endpoint
Get User Information by access_token
The OAuth User Endpoint */api/oauth/user* is responsible for providing user information by OAuth tokens. Internally it calls the SAP HCP internal *oauth2* HTTP Destination to get the information.

###### Request
The following HTTP GET request sends an OAuth token as value of the access_token property.

```

GET /api/oauth/user?access_token=6f959a75f39bfbb476a583a976a59772 HTTP/1.1
Accept: application/json

```

###### Response
The following HTTP GET response shows the information of the user or client that requested that OAuth token. In this case it was an OAuth Client therefore the clientid, scopes and the grantType of the OAuth Client are returned. In other cases where a OAuth token was issued for a user, the user information are returned.

```

HTTP/1.1 200 OK
Content-Type: application/json;charset=utf-8

{"user":{"clientid":"e750cded-3b19-3293-b2da-ed8e39d72c1a","scopes":["E-Bike-Data"],"grantType":"CLIENTGRANT"}}

```

